﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EC_two____Assignment.Models;

namespace EC_two____Assignment.Controllers
{
    public class productController : Controller
    {
        //
        // GET: /product/

        public ActionResult Index()
        {
            var p = new prod_context();
            List<product> lst = p.prod_w.SqlQuery("select * from products").ToList<product>();
            List<product> lst_n = new List<product>();
            foreach (var prd in lst)
            {
                byte[] img_b = prd.image;
                string img_s = Convert.ToBase64String(img_b, 0, img_b.Length);
                prd.img = "data:image/png;base64," + img_s;
                lst_n.Add(prd);
            }
            return View(lst_n);
        }

        //
        // GET: /product/Details/5

        public ActionResult Details(int id)
        {
            var p = new prod_context();
            product w = p.prod_w.Find(id);
            byte[] img_b = w.image;
            string img_s = Convert.ToBase64String(img_b, 0, img_b.Length);
            w.img = "data:image/png;base64," + img_s;
            return View(w);
        }

        //
        // GET: /product/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /product/Create

        [HttpPost]
        public ActionResult Create([Bind(Include="id,name,price,m_name,quantity")]product w, FormCollection collection)
        {
            try
            {
                /*int id = Convert.ToInt16(collection["id"]);
                string name = collection["name"];
                double price = Convert.ToDouble(collection["price"]);
                */
                byte[] image = System.IO.File.ReadAllBytes(collection["i_pn"]);
                /*string m_name = collection["m_name"];
                int quantity = Convert.ToInt16(collection["quantity"]);*/

                // TODO: Add insert logic here
                prod_context p = new prod_context();
                //product w = new product() { id = id, name = name, price = price, img = null, image = image, m_name = m_name, quantity = quantity };                
                w.image = image;
                p.prod_w.Add(w);
                //p.Entry(w).State = EntityState.Added;
                p.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        
        //
        // GET: /product/Edit/5
 
        public ActionResult Edit(int id)
        {
            var p = new prod_context();
            product w = p.prod_w.Find(id);
            return View(w);
        }

        //
        // POST: /product/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                string name = collection["name"];
                float price = (float)Convert.ToDouble(collection["price"]);
                //
                byte[] image = System.IO.File.ReadAllBytes(collection["i_pn"]);
                string m_name = collection["m_name"];
                int quantity = Convert.ToInt16(collection["quantity"]);
                // TODO: Add update logic here
                var p = new prod_context();
                var w = p.prod_w.Find(id);
                w.name = name;
                w.price = price;
                w.img = null;
                w.image = image;
                w.m_name = m_name;
                w.quantity = quantity;
                p.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /product/Delete/5
 
        public ActionResult Delete(int id)
        {
            var p = new prod_context();
            product w = p.prod_w.Find(id);
            return View(w);
        }

        //
        // POST: /product/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                var p = new prod_context();
                var w = p.prod_w.Find(id);
                p.prod_w.Remove(w);
                p.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
