﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using System.Web.Security;
using EC_two____Assignment.Models;

namespace EC_two____Assignment.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Welcome to a watch store";//ASP.NET MVC!";

            return View();
        }

        public ActionResult The_products() 
        {
            List<product> lst = new List<product>();
            string constr = "Data Source=LAPTOP-RD6SKICU\\SQLEXPRESS;Initial Catalog=EC_two____Assignment.Models.prod_context;Integrated Security=True";
            SqlConnection conn = new SqlConnection(constr);
            conn.Open();
            SqlCommand comm = new SqlCommand(constr, conn);
            comm.Connection = conn;
            comm.CommandText = "select * from products";
            SqlDataReader dr = comm.ExecuteReader();
            while (dr.Read())
            {
                product prod = new product();
                prod.id = (int)dr["id"];
                prod.name = dr["name"].ToString();
                prod.price = Convert.ToDouble(dr["price"]);
                byte[] img = (byte[])dr["image"];
                string img_s = Convert.ToBase64String(img, 0, img.Length);
                prod.img = "data:image/png;base64," + img_s;
                prod.m_name = dr["m_name"].ToString();
                prod.quantity = (int)dr["quantity"];
                lst.Add(prod);
            }
            dr.Close();
            TempData["prods"] = lst;
            JavaScriptSerializer js_obj = new JavaScriptSerializer();
            js_obj.MaxJsonLength = 10000000;
            string data = js_obj.Serialize(lst);
            TempData["js_prods"] = data;
            List<SelectListItem> opt = new List<SelectListItem>();
            foreach (var option in lst)
            {
                opt.Add(new SelectListItem { Text = option.name, Value = option.id.ToString() });
            }
            ViewBag.sel_opt = opt;
            return View();
        }

        public ActionResult The_admin()
        {
            return View();
        }

        public ActionResult order_history()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Confirmation()
        {
            return View();
        }

        public ActionResult upd_usr(string usr, string rol)
        {
            bool stat;
            Roles.AddUserToRole(usr, rol);
            stat = Roles.IsUserInRole(usr, rol);
            return this.Json(new { usr, rol, stat });
        }

        public ActionResult gr(string usr)
        {
            string[] rol = Roles.GetRolesForUser(usr);
            return this.Json(new { usr, rol });
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
