﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EC_two____Assignment.Models
{
    public class product
    {
        [Key]
        public int id { get; set; }
        [Required(ErrorMessage="please put a brand name")]
        [Display(Name = "brand name")]
        public string name { get; set; }
        [Required(ErrorMessage="please put a price")]
        public double price { get; set; }        
        [Display(Name = "model name")]
        public string m_name { get; set; }
        [Required(ErrorMessage="please put the quantity")]
        public int quantity { get; set; }
        [Display(Name = "image")]
        public string img { get; set; }
        public byte[] image { get; set; }
    }
}