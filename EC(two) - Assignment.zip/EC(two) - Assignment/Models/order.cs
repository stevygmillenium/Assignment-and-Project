﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EC_two____Assignment.Models
{
    public class order
    {
        [Required]
        public string order_id { get; set; }
        [Required]
        public string cust_name { get; set; }
        [DataType(DataType.EmailAddress)]
        public string cust_email { get; set; }
        public string c_address { get; set; }
        public string prod_id_info { get; set; }
        public DateTime order_date { get; set; }
    }
}