﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace EC_two____Assignment.Models
{
    public class prod_context:DbContext
    {
        //public prod_context() : base("ApplicationServices") { }
        public DbSet<product> prod_w { get; set; }
    }
}