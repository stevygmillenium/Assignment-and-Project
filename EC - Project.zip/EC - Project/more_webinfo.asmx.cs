﻿using System;
using System.IO;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Runtime.Serialization.Json;
using System.Xml;
using System.Xml.Serialization;
using Newtonsoft.Json;

namespace EC___Project
{
    /// <summary>
    /// Summary description for more_webinfo
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class more_webinfo : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";

        }
        [WebMethod]
        public float showprices() 
        {
            Random rand = new Random();
            float price = (float)rand.NextDouble() * (300 - 100) + 100;
            Application["price"] = price;
            return price;
        }

        public class exchangerate
        {
            public float us, cn, pound, euro;
            //public DateTime date { get; set; }

            public exchangerate()
            {
                us = 0;
                cn = 0;
                pound = 0;
                euro = 0;
                //date = DateTime.Now;
            }
        }
        [WebMethod]
        public string exch_rates()//calculate exchange rate
        {
            string json=null;
            if (Application["price"] == null) { json = "no data!"; }
            else
            {
                float price = (float)Application["price"];
                string info = new WebClient().DownloadString("https://api.exchangerate-api.com/v4/latest/USD");
                dynamic j_data = new JavaScriptSerializer().Deserialize<object>(info);
                exchangerate currency = new exchangerate();
                currency.us = price * j_data["rates"]["USD"];
                currency.cn = price * (float)j_data["rates"]["CAD"];
                currency.pound = price * (float)j_data["rates"]["GBP"];
                currency.euro = price * (float)j_data["rates"]["EUR"];
                var j_obj = new JavaScriptSerializer().Serialize(currency);
                //Response.Write(j_obj);
                json = "currency: " + j_obj;
                XmlSerializer xml_s = new XmlSerializer(currency.GetType());
                XmlDocument xml_d = new XmlDocument();
                MemoryStream ms = new MemoryStream();
                xml_s.Serialize(ms, currency);
                ms.Position = 0;
                xml_d.Load(ms);
                xml_d.Save(@"c:\Users\shawn\Documents\Visual Studio 2010\Projects\EC - Project\new_xml.xml");
                var j_obj_m = new DataContractJsonSerializer(currency.GetType());
                string file_path = @"c:\Users\shawn\Documents\Visual Studio 2010\Projects\EC - Project\new_json.json";
                TextWriter tw = new StreamWriter(file_path);
                MemoryStream ms_m = new MemoryStream();
                j_obj_m.WriteObject(ms_m, currency);
                ms_m.Position = 0;
                StreamReader sr = new StreamReader(ms_m);
                string data = sr.ReadToEnd();
                tw.Write(data);
                string data_m = JsonConvert.SerializeObject(currency);
                var obj = JsonConvert.DeserializeObject<exchangerate>(data_m);
                tw.Close();
            }
            return json;
        }
        [WebMethod]
        public int seat_selection() {
            Random rand = new Random();
            int seat = rand.Next(1, 100);
            return seat;
        }
        [WebMethod]
        public int ticket_number() {
            string ticket_num;
            ticket_num = Convert.ToString(DateTime.Now.Hour + "" + DateTime.Now.Minute + "" + DateTime.Now.Second + "" + DateTime.Now.Millisecond);
            Int32 ticket_number = Convert.ToInt32(ticket_num);
            return ticket_number;
        }
        [WebMethod]
        public int room_selection()
        {
            Random rand = new Random();
            int room = rand.Next(1, 100);
            return room;
        }
        [WebMethod]
        public string more_data()//web data retrieval
        {
            string data = new WebClient().DownloadString("https://freegeoip.app/json/"), country_name, city, country_code, output;
            dynamic j_data = new JavaScriptSerializer().Deserialize<object>(data);
            country_code = j_data["country_code"];
            country_name = j_data["country_name"];
            city = j_data["city"];
            decimal lat = j_data["latitude"], lon = j_data["longitude"];
            string data_m = new WebClient().DownloadString("https://date.nager.at/api/v2/publicholidays/" + DateTime.Now.Year.ToString() + "/" + country_code), localName = null;
            dynamic j_data_m = new JavaScriptSerializer().Deserialize<object>(data_m);
            object[] obj = j_data_m;
            DateTime h_date = DateTime.Now;
            for (int i = 0; i < obj.Length; i++)
            {
                if (Convert.ToDateTime(j_data_m[i]["date"]) > h_date)
                {
                    h_date = Convert.ToDateTime(j_data_m[i]["date"]);
                    localName = j_data_m[i]["localName"]; break;
                }
                else { }
            }
            string data_n = new WebClient().DownloadString("https://www.boredapi.com/api/activity"), activity;
            dynamic j_data_n = new JavaScriptSerializer().Deserialize<object>(data_n);
            activity = j_data_n["activity"];
            output = country_name + ", " + city + " " + lat + " " + lon + " " + " next holiday: " + h_date + " " + localName + " activity suggestions: " + activity;
            return output;
        }
        [WebMethod]
        public double c_data(string city_from,string city_to) {//get distance between cities
            string data = new WebClient().DownloadString("https://www.distance24.org/route.json?stops=" + city_from + "|" + city_to);
            dynamic j_data = new JavaScriptSerializer().Deserialize<object>(data);
            double dist = j_data["distance"];
            return dist;
        }
    }
}