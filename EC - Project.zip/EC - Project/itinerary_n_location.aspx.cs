﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Collections;
using System.Net;
//using System.Runtime.Serialization;

namespace EC___Project
{
    public partial class itinerary_n_location : System.Web.UI.Page
    {
        string user_n = HttpContext.Current.User.Identity.Name;
        string email = null;
        string[] month = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" }, c_type = { "Visa", "Mastercard", "PayPal", "Other..." };
        int[] year = { 2020, 2021, 2022 };
        more_webinfo information = new more_webinfo();
        DateTime dt=DateTime.Now;
        TimeSpan ts;
        float price;
        int number_of_adults = 0,days,hour,minute,sec;        
        protected void Page_Load(object sender, EventArgs e)
        {            
            Image1.ImageUrl = "https://seeklogo.com/images/C/credit-card-icons-logo-9CC8F1BFCD-seeklogo.com.png";
            ImageButton1.Width = 124;
            ImageButton1.Height = ImageButton1.Width;
            ImageButton1.ImageUrl = "~/image/three/hiclipart.com.png";
            ImageButton2.Width = ImageButton1.Width;
            ImageButton2.Height = 122;
            ImageButton2.ImageUrl = "~/image/ClipartKey_3060940.png";
            price =information.showprices();              
            if (user_n == "")
            {
                Label3.Text = "not logged in!";
            }
            else
            {
                if (HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    email = Membership.GetUser().Email;
                }
                else { }
                Label3.Text = "user name: " + user_n;
                TextBox1.Text = email;
            }
            Label1.Text = Request.Form["entity"];
            Application["ent"] = Label1.Text;
            if (Label1.Text == "La Quinta" || Label1.Text == "Days Inn" || Label1.Text == "Super 8")
            {
                Label2.Text = "hotel";
                HiddenField1.Value = (string)Application["ent"];
            }
            else if (Label1.Text == "American Airlines" || Label1.Text == "JetBlue") 
            {
                Label2.Text = "airline";
                HiddenField1.Value = (string)Application["ent"];
            }
            else if (Label1.Text == "Carnival" || Label1.Text == "Royal Caribbean") 
            {
                Label2.Text = "ship";
                HiddenField1.Value = (string)Application["ent"];
            }
            //var j_data = JsonReaderWriterFactory.CreateJsonReader(); 
            Label5.Text = information.more_data();
        }

        protected void Button1_Click(object sender, EventArgs e)//get price with currency conversion
        {
            DropDownList1.DataSource = month;
            DropDownList1.DataBind();
            DropDownList2.DataSource = year;
            DropDownList2.DataBind();
            RadioButtonList1.DataSource = c_type;
            RadioButtonList1.DataBind();
            if (Label2.Text == "hotel") 
            {
                if (ListBox2.SelectedValue == "4") 
                {
                    Label3.Text =Convert.ToString(price);
                    Label4.Text=information.exch_rates();
                }
                else if (ListBox2.SelectedValue == "5")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox2.SelectedValue == "6")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox2.SelectedValue == "7")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox2.SelectedValue == "8")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox2.SelectedValue == "9")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else { Label3.Text = "invalid selection."; }
            }
            else if (Label2.Text == "airline") 
            {
                if (ListBox1.SelectedValue == "1" && ListBox2.SelectedValue == "4") 
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "1" && ListBox2.SelectedValue == "5")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "1" && ListBox2.SelectedValue == "6")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "1" && ListBox2.SelectedValue == "7")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "1" && ListBox2.SelectedValue == "8")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "1" && ListBox2.SelectedValue == "9")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "3" && ListBox2.SelectedValue == "4")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "3" && ListBox2.SelectedValue == "5")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "3" && ListBox2.SelectedValue == "6")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "3" && ListBox2.SelectedValue == "7")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "3" && ListBox2.SelectedValue == "8")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "4" && ListBox2.SelectedValue == "9")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else { Label3.Text = "invalid combination!"; }
            }
            else if (Label2.Text == "ship")
            {
                if (ListBox1.SelectedValue == "2" && ListBox2.SelectedValue == "4")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "2" && ListBox2.SelectedValue == "5")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "2" && ListBox2.SelectedValue == "6")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "2" && ListBox2.SelectedValue == "7")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "2" && ListBox2.SelectedValue == "8")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "2" && ListBox2.SelectedValue == "9")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "3" && ListBox2.SelectedValue == "4")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "3" && ListBox2.SelectedValue == "5")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "3" && ListBox2.SelectedValue == "6")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "3" && ListBox2.SelectedValue == "7")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "3" && ListBox2.SelectedValue == "8")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else if (ListBox1.SelectedValue == "4" && ListBox2.SelectedValue == "9")
                {
                    Label3.Text = Convert.ToString(price);
                    Label4.Text = information.exch_rates();
                }
                else { Label3.Text = "invalid combination!"; }
            }
            else { }
        }

        public class hotel 
        {
            public int tr_id, room_num;
            public string hotel_name, room_type, cust_name, cust_email, additional_name;
            public DateTime check_in, check_out;
            public float room_price;

            public hotel() 
            {
                tr_id = 0;
                room_num = 0;
                hotel_name = "";
                room_type = "";
                cust_name = "";
                cust_email = "";
                additional_name = "";
                check_in = DateTime.Now;
                check_out = DateTime.Now;
                room_price = 0.00f;
            }
        }

        public class airline 
        {
            public int tr_id, seat_number, ticket_num;
            public string airline_name, cust_name, cust_email, additional_name;
            public DateTime departure, return_d;
            public float flight_price;

            public airline() 
            {
                tr_id = 0;
                seat_number = 0;
                ticket_num = 0;
                airline_name = "";
                cust_name = "";
                cust_email = "";
                additional_name = "";
                departure = DateTime.Now;
                return_d = DateTime.Now;
                flight_price = 0.00f;
            }
        }

        public class ship 
        {
            public int tr_id, room_num;
            public string ship_name, room_type, cust_name, cust_email, additional_name;
            public DateTime departure, return_d;
            public float cruise_price;

            public ship() 
            {
                tr_id = 0;
                room_num = 0;
                ship_name = "";
                room_type = "";
                cust_name = "";
                cust_email = "";
                additional_name = "";
                departure = DateTime.Now;
                return_d = DateTime.Now;
                cruise_price = 0.00f;
            }
        }
                
        protected void Button2_Click(object sender, EventArgs e)//book reservation
        {
            //Response.Write(DropDownList1.SelectedItem.Text + DropDownList2.SelectedItem.Value + RadioButtonList1.SelectedItem.Text);
            ts = Calendar2.SelectedDate - Calendar1.SelectedDate;
            hour = dt.Hour+4;
            minute = dt.Minute;
            sec = dt.Second;
            if (Label2.Text == "hotel")
            {
                hotel land = new hotel();
                land.hotel_name = HiddenField1.Value;
                days = ts.Days;
                land.room_num = information.room_selection();
                land.room_type = ListBox3.SelectedItem.Text;
                land.room_price =((float) Application["price"]*days);
                land.check_in = Calendar1.SelectedDate.AddHours(hour)
                    .AddMinutes(minute)
                    .AddSeconds(sec);
                land.check_out = Calendar2.SelectedDate.AddHours(hour-4)
                    .AddMinutes(minute)
                    .AddSeconds(sec);
                land.cust_email = TextBox1.Text;
                land.cust_name = TextBox2.Text;
                land.additional_name = TextBox3.Text;
                string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                SqlConnection conn = new SqlConnection(constr);
                conn.Open();
                SqlCommand comm = new SqlCommand(constr, conn);
                comm.CommandText = "insert into hotel_data (hotel_name,room_num,room_type,room_price,check_in,check_out,cust_name,cust_email,additional_name,city_from,city_to,book_d) values (@hotel_name,@room_num,@room_type,@room_price,@check_in,@check_out,@cust_name,@cust_email,@additional_name,@city_from,@city_to,@book_d);";
                comm.Parameters.Add("@hotel_name", land.hotel_name);
                comm.Parameters.Add("@room_num", land.room_num);
                comm.Parameters.Add("@room_type", land.room_type);
                comm.Parameters.Add("@room_price", land.room_price);
                comm.Parameters.Add("@check_in", land.check_in);
                comm.Parameters.Add("@check_out", land.check_out);
                comm.Parameters.Add("@cust_name", land.cust_name);
                comm.Parameters.Add("@cust_email", land.cust_email);
                comm.Parameters.Add("@additional_name", land.additional_name);
                comm.Parameters.Add("@city_from", ListBox1.SelectedItem.Text);
                comm.Parameters.Add("@city_to", ListBox2.SelectedItem.Text);
                comm.Parameters.Add("@book_d", dt);
                comm.ExecuteNonQuery();
                conn.Close();
            }
            else if (Label2.Text == "airline")
            {
                airline air = new airline();
                air.airline_name = HiddenField1.Value;
                air.seat_number = information.seat_selection();
                air.flight_price = (float)Application["price"];
                air.departure = Calendar1.SelectedDate.AddHours(hour)
                    .AddMinutes(minute)
                    .AddSeconds(sec);
                air.return_d = Calendar2.SelectedDate.AddHours(hour-4)
                    .AddMinutes(minute)
                    .AddSeconds(sec);
                air.ticket_num = information.ticket_number();
                air.cust_email = TextBox1.Text;
                air.cust_name = TextBox2.Text;
                air.additional_name = TextBox3.Text;
                string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                SqlConnection conn = new SqlConnection(constr);
                conn.Open();
                SqlCommand comm = new SqlCommand(constr, conn);
                comm.CommandText = "insert into flight_data (airline_name,seat_number,flight_price,departure,return_d,ticket_num,cust_name,cust_email,additional_name,city_from,city_to,book_d) values (@airline_name,@seat_number,@flight_price,@departure,@return_d,@ticket_num,@cust_name,@cust_email,@additional_name,@city_from,@city_to,@book_d);";
                comm.Parameters.Add("@airline_name", air.airline_name);
                comm.Parameters.Add("@seat_number", air.seat_number);
                comm.Parameters.Add("@flight_price", air.flight_price);
                comm.Parameters.Add("@departure", air.departure);
                comm.Parameters.Add("@return_d", air.return_d);
                comm.Parameters.Add("@ticket_num", air.ticket_num);
                comm.Parameters.Add("@cust_name", air.cust_name);
                comm.Parameters.Add("@cust_email", air.cust_email);
                comm.Parameters.Add("@additional_name", air.additional_name);
                comm.Parameters.Add("@city_from", ListBox1.SelectedItem.Text);
                comm.Parameters.Add("@city_to", ListBox2.SelectedItem.Text);
                comm.Parameters.Add("@book_d", dt);
                comm.ExecuteNonQuery();
                conn.Close();
            }
            else if (Label2.Text == "ship") 
            {
                ship sea = new ship();
                sea.ship_name=HiddenField1.Value;
                days = ts.Days;
                sea.room_num = information.room_selection();
                sea.room_type = ListBox3.SelectedItem.Text;
                sea.cruise_price = ((float)Application["price"]*days);
                sea.departure = Calendar1.SelectedDate.AddHours(hour)
                    .AddMinutes(minute)
                    .AddSeconds(sec);
                sea.return_d = Calendar1.SelectedDate.AddHours(hour-4)
                    .AddMinutes(minute)
                    .AddSeconds(sec);
                sea.cust_email = TextBox1.Text;
                sea.cust_name = TextBox2.Text;
                sea.additional_name = TextBox3.Text;
                string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                SqlConnection conn = new SqlConnection(constr);
                conn.Open();
                SqlCommand comm = new SqlCommand(constr, conn);
                comm.CommandText = "insert into cruise_data (ship_name,room_num,room_type,cruise_price,departure,return_d,cust_name,cust_email,additional_name,city_from,city_to,book_d) values (@ship_name,@room_num,@room_type,@cruise_price,@departure,@return_d,@cust_name,@cust_email,@additional_name,@city_from,@city_to,@book_d);";
                comm.Parameters.Add("@ship_name", sea.ship_name);
                comm.Parameters.Add("@room_num", sea.room_num);
                comm.Parameters.Add("@room_type", sea.room_type);
                comm.Parameters.Add("@cruise_price", sea.cruise_price);
                comm.Parameters.Add("@departure", sea.departure);
                comm.Parameters.Add("@return_d", sea.return_d);
                comm.Parameters.Add("@cust_name", sea.cust_name);
                comm.Parameters.Add("@cust_email", sea.cust_email);
                comm.Parameters.Add("@additional_name", sea.additional_name);
                comm.Parameters.Add("@city_from", ListBox1.SelectedItem.Text);
                comm.Parameters.Add("@city_to", ListBox2.SelectedItem.Text);
                comm.Parameters.Add("@book_d", dt);
                comm.ExecuteNonQuery();
                conn.Close();
            }
            else{}
        }

        protected void Button3_Click(object sender, EventArgs e)//check reservation
        {
            DataTable tab = new DataTable();
            if (Label2.Text == "hotel")
            {
                tab.Columns.Add("tr_id");
                tab.Columns.Add("hotel_name");
                tab.Columns.Add("room_num");
                tab.Columns.Add("room_type");
                tab.Columns.Add("room_price");
                tab.Columns.Add("check_in");
                tab.Columns.Add("check_out");
                tab.Columns.Add("cust_name");
                tab.Columns.Add("cust_email");
                tab.Columns.Add("additional_name");
                tab.Columns.Add("city_from");
                tab.Columns.Add("city_to");
                tab.Columns.Add("book_d");
                string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                SqlConnection conn = new SqlConnection(constr);
                conn.Open();
                SqlCommand comm = new SqlCommand(constr, conn);
                comm.Connection=conn;
                comm.CommandText = "select * from hotel_data where cust_email='" + TextBox1.Text + "'";
                SqlDataAdapter da = new SqlDataAdapter(comm);
                da.Fill(tab);
                conn.Close();
                GridView1.DataSource = tab;
                GridView1.DataBind();
            }
            else if (Label2.Text == "airline")
            {
                tab.Columns.Add("tr_id");
                tab.Columns.Add("airline_name");
                tab.Columns.Add("seat_number");
                tab.Columns.Add("flight_price");
                tab.Columns.Add("departure");
                tab.Columns.Add("return_d");
                tab.Columns.Add("ticket_num");
                tab.Columns.Add("cust_name");
                tab.Columns.Add("cust_email");
                tab.Columns.Add("additional_name");
                tab.Columns.Add("city_from");
                tab.Columns.Add("city_to");
                tab.Columns.Add("book_d");
                string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                SqlConnection conn = new SqlConnection(constr);
                conn.Open();
                SqlCommand comm = new SqlCommand(constr, conn);
                comm.Connection=conn;
                comm.CommandText = "select * from flight_data where cust_email='" + TextBox1.Text + "'";
                SqlDataAdapter da = new SqlDataAdapter(comm);
                da.Fill(tab);
                conn.Close();
                GridView1.DataSource = tab;
                GridView1.DataBind();
            }
            else if (Label2.Text == "ship")
            {
                tab.Columns.Add("tr_id");
                tab.Columns.Add("ship_name");
                tab.Columns.Add("room_num");
                tab.Columns.Add("room_type");
                tab.Columns.Add("cruise_price");
                tab.Columns.Add("departure");
                tab.Columns.Add("return_d");
                tab.Columns.Add("cust_name");
                tab.Columns.Add("cust_email");
                tab.Columns.Add("additional_name");
                tab.Columns.Add("city_from");
                tab.Columns.Add("city_to");
                tab.Columns.Add("book_d");
                string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                SqlConnection conn = new SqlConnection(constr);
                conn.Open();
                SqlCommand comm = new SqlCommand(constr, conn);
                comm.Connection=conn;
                comm.CommandText = "select * from cruise_data where cust_email='" + TextBox1.Text + "'";
                SqlDataAdapter da = new SqlDataAdapter(comm);
                da.Fill(tab);
                conn.Close();
                GridView1.DataSource = tab;
                GridView1.DataBind();
            }
            else { }
        }            

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {//download exchange rates xml file
            string file_path = "c:\\Users\\shawn\\Documents\\Visual Studio 2010\\Projects\\EC - Project\\new_xml.xml";
            FileInfo fi = new FileInfo(file_path);
            if (fi.Exists)
            {
                Response.Clear();
                Response.AddHeader("Content-Disposition", "attachment; filename=" + fi.Name);
                Response.AddHeader("Content-Length", fi.Length.ToString());
                Response.ContentType = "text/plain";
                Response.Flush();
                Response.TransmitFile(fi.FullName);///
                Response.End();
            }
            else { }
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            Label6.Text = "distance (km): " + Convert.ToString(information.c_data(ListBox1.SelectedItem.Text, ListBox2.SelectedItem.Text));///
        }
    }
}