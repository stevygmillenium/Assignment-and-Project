﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace EC___Project
{
    public partial class _Default : System.Web.UI.Page
    {
        string user_n = HttpContext.Current.User.Identity.Name;
        string email = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (user_n == "")
            {
                Label1.Text = "not logged in!";
            }
            else
            {
                if (HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    email = Membership.GetUser().Email;
                }
                else { }
                Label1.Text = "user name: " + user_n;
                TextBox1.Text = email;
            }
            Image1.ImageUrl = "http://clipartbarn.com/wp-content/uploads/2017/09/Travel-clipart-collection.jpg"; 

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("availability.htm");
        }
               
    }
}
