﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace EC___Assignment
{
    /// <summary>
    /// Summary description for Veh_image
    /// </summary>
    public class Veh_image : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            /*context.Response.ContentType = "text/plain";
            context.Response.Write("Hello World");*/
            string id = context.Request.QueryString["p_id"];
            string constr = ConfigurationManager.ConnectionStrings["ec_projConnectionString"].ConnectionString;
            SqlConnection conn = new SqlConnection(constr);
            conn.Open();
            SqlCommand comm = new SqlCommand(constr, conn);
            comm.Connection = conn;
            comm.CommandText = "select * from v_product where prod_id=" + id;
            SqlDataReader dr = comm.ExecuteReader();
            dr.Read();
            byte[] img = (byte[])dr["prod_image"] as byte[];
            context.Response.BinaryWrite(img);
            context.Response.End();
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}