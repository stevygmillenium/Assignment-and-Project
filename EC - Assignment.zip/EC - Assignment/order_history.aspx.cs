﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace EC___Assignment
{
    public partial class order_history : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string user_n = HttpContext.Current.User.Identity.Name;
            string email=null;
            if (user_n == "")
            {
                Label1.Text = "not logged in!";
                //Response.Write("What!");
            }
            else
            {
                if (HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    email = Membership.GetUser().Email;
                }
                else { }
                Label1.Text = "user name: " + user_n;
                //Response.Write("u name: " + user_n+" email :"+email);
                TextBox1.Text = email;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable tab = new DataTable();
            tab.Columns.Add("order_num");
            tab.Columns.Add("cust_email");
            tab.Columns.Add("cust_name");
            tab.Columns.Add("c_address");
            tab.Columns.Add("prod_id_info");
            tab.Columns.Add("order_date");
            tab.Columns.Add("StartDate");
            tab.Columns.Add("EndDate");
            tab.Columns.Add("NumberOfDays");
            tab.Columns.Add("g_total");
            string constr = ConfigurationManager.ConnectionStrings["ec_projConnectionString"].ConnectionString;
            SqlConnection conn = new SqlConnection(constr);
            conn.Open();
            SqlCommand comm = new SqlCommand(constr, conn);
            comm.Connection = conn;
            comm.CommandText = "select * from rental_order where cust_email='" + TextBox1.Text+"'";
            //SqlDataReader dr = comm.ExecuteReader();
            //dr.Read();
            SqlDataAdapter da=new SqlDataAdapter(comm);
            da.Fill(tab);
            conn.Close();
            GridView1.DataSource = tab;
            GridView1.DataBind();
        }
    }
}