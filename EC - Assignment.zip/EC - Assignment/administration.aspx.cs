﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace EC___Assignment
{
    public partial class administration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["ec_projConnectionString"].ConnectionString;
            SqlConnection conn = new SqlConnection(constr);
            conn.Open();
            SqlCommand comm = new SqlCommand(constr, conn);
            comm.CommandText = "insert into v_product (prod_id,prod_name,descript,category,unit_price,prod_image) values (@prod_id,@prod_name,@prod_desc,@prod_cat,@unit_p,@v_image)";
            comm.Parameters.Add("@prod_id", int.Parse(TextBox1.Text));
            comm.Parameters.Add("@prod_name", TextBox2.Text);
            comm.Parameters.Add("@prod_desc", TextBox3.Text);
            comm.Parameters.Add("@prod_cat", TextBox4.Text);
            comm.Parameters.Add("@unit_p", float.Parse(TextBox5.Text));
            comm.Parameters.Add("@v_image", FileUpload1.PostedFile.InputStream);
            comm.ExecuteNonQuery();
            conn.Close();
            Label1.Text = "added!";
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["ec_projConnectionString"].ConnectionString;
            SqlConnection conn = new SqlConnection(constr);
            conn.Open();
            SqlCommand comm = new SqlCommand(constr, conn);
            comm.CommandText = "delete from v_product where prod_id=" + TextBox1.Text;
            comm.ExecuteNonQuery();
            conn.Close();
            Label1.Text = "deleted.";
        }
    }
}