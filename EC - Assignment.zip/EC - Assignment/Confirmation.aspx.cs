﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.IO;
using System.Text;

namespace EC___Assignment
{
    public partial class Confirmation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable tb = Application["v_data"] as DataTable;
            StringBuilder sb = new StringBuilder();
            foreach (DataRow row in tb.Rows)
            {
                string p_id = (string)row["id"];
                Response.Write(p_id);
                sb.Append(p_id);
            }
            string id_info =Convert.ToString(sb);
            //Label1.Text = Convert.ToString(sb);
            HiddenField1.Value = Request.Form["c_type"];
            string addr, nm, email = Request.Form["email"], card_type = HiddenField1.Value;
            addr = Request.Form["address"];
            nm = Request.Form["card_name"];
            Int64 card_num = Int64.Parse(Request.Form["card_num"]);
            int days_num;
            StreamReader sr = new StreamReader(@"c:\Users\shawn\Documents\Visual Studio 2010\Projects\EC - Assignment\info.txt");
            //int p_id = int.Parse(sr.ReadLine());
            //pn = sr.ReadLine();
            float gt = float.Parse(sr.ReadLine());
            DateTime start_date, fin_date;
            start_date = DateTime.Parse(sr.ReadLine());
            fin_date = DateTime.Parse(sr.ReadLine());
            TimeSpan diff = fin_date - start_date;
            days_num = diff.Days;
            Response.Write(addr+" "+nm+" "+card_num+" "+sb+" "+gt+" "+start_date+" "+fin_date+" "+card_type);
            rental_confirm rc=new rental_confirm();
            string constr = ConfigurationManager.ConnectionStrings["ec_projConnectionString"].ConnectionString;
            SqlConnection conn = new SqlConnection(constr);
            conn.Open();
            SqlCommand comm = new SqlCommand(constr, conn);
            comm.CommandText = "insert into rental_order (prod_id_info,cust_email,order_date,StartDate,EndDate,NumberOfDays,g_total,c_address,cust_name) values (@prod_id,@cust_email,getdate(),@Start_Date,@End_Date,@d_num,@g_Total,@address,@cust_nm)";
            comm.Parameters.Add("@prod_id", id_info);
            comm.Parameters.Add("@cust_email",email);
            comm.Parameters.Add("@Start_Date",start_date);
            comm.Parameters.Add("@End_Date",fin_date);
            comm.Parameters.Add("@d_num", days_num);
            comm.Parameters.Add("@g_Total",gt);
            comm.Parameters.Add("@cust_nm", nm);
            comm.Parameters.Add("@address", addr);
            comm.ExecuteNonQuery();
            SqlCommand comm2 = new SqlCommand(constr, conn);
            comm2.CommandText = "declare @maximum int;select @maximum = MAX(order_num) from rental_order;select * from rental_order where order_num=@maximum;";
            SqlDataReader dr = comm2.ExecuteReader();
            dr.Read();
            rc.order_num = (int)dr["order_num"];
            rc.prod_id = (string)dr["prod_id_info"];
            rc.email = (string)dr["cust_email"];
            rc.cust_name = (string)dr["cust_name"];
            rc.address = (string)dr["c_address"];
            rc.order_date = (DateTime)dr["order_date"];
            rc.st_date = Convert.ToDateTime(dr["StartDate"]);
            rc.en_date = Convert.ToDateTime(dr["EndDate"]);
            rc.num_days = (int)dr["NumberOfDays"];
            rc.g_total = (float)(double) dr["g_total"];
            Response.Write("\n"+rc.order_num+rc.prod_id+rc.email+rc.order_date+rc.st_date+rc.en_date);
            Label1.Width = 1150;
            Label2.Width = 1150;
            Label1.Text = "order id: " + rc.order_num + " product id: " + rc.prod_id+"email: "+rc.email+" order date: "+rc.order_date;
            Label2.Text = "start date: "+rc.st_date+" end date: "+rc.en_date+" number of days: "+rc.num_days+" grand total: "+rc.g_total;
            conn.Close();            
        }

        public class rental_confirm {
            public int order_num, num_days;
            public string prod_id, email,cust_name,address;
            public DateTime order_date, st_date, en_date;
            public float g_total;

            public rental_confirm()
            {
                order_num = 0;
                prod_id = "";
                num_days = 0;
                email = "";
                address = "";
                cust_name = "";
                order_date = DateTime.Now;
                st_date = DateTime.Now;
                en_date = DateTime.Now;
                g_total = 0.00f;
            }
        }       
    }
}