﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace EC___Assignment
{
    public partial class VehiC : System.Web.UI.Page
    {
        DataTable table = new DataTable();
        float g_total;
        protected string u_email;
        protected void Page_Load(object sender, EventArgs e)
        {
            table.Columns.Add("id");
            table.Columns.Add("name");
            table.Columns.Add("description");
            table.Columns.Add("category");
            table.Columns.Add("unit_price_per_day");
            table.Columns.Add("days_amt_num");
            table.Columns.Add("sub_total");
            table.Columns.Add("prod_image");
            table.Columns.Add("select_box");            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Product vehicle = new Product();
            DateTime start_date, fin_date;
            start_date = Calendar1.SelectedDate;
            fin_date = Calendar2.SelectedDate;
            TimeSpan diff = fin_date - start_date;
            int days_num = diff.Days;
            Session["s_date"] = start_date;
            Session["e_date"] = fin_date;
            Session["amount"] = days_num;
            foreach (int i in ListBox1.GetSelectedIndices())
            {
                int p_id = int.Parse(ListBox1.Items[i].Value);
                string constr = ConfigurationManager.ConnectionStrings["ec_projConnectionString"].ConnectionString;
                SqlConnection conn = new SqlConnection(constr);
                conn.Open();
                SqlCommand comm = new SqlCommand(constr, conn);
                comm.Connection = conn;
                comm.CommandText = "select * from v_product where prod_id=" + p_id;
                SqlDataReader dr = comm.ExecuteReader();
                dr.Read();
                vehicle.id = (int)dr["prod_id"];
                vehicle.name= Convert.ToString(dr["prod_name"]);
                vehicle.description= Convert.ToString(dr["descript"]);
                vehicle.category= Convert.ToString(dr["category"]);
                vehicle.unit_price_per_day= (float)(double)dr["unit_price"];
                byte[] img = (byte[])dr["prod_image"] as byte[];
                string img_s = Convert.ToBase64String(img, 0, img.Length);
                Image image = new Image();
                image.ImageUrl = "data:image/png;base64," + img_s;
                float sub_total=vehicle.unit_price_per_day*days_num;
                g_total = g_total + sub_total;
                table.Rows.Add(vehicle.id, vehicle.name, vehicle.description, vehicle.category, vehicle.unit_price_per_day,days_num, sub_total,image.ImageUrl, null);
                conn.Close();
            }
            GridView1.DataSource = table;
            GridView1.DataBind();
            Label1.Text = "" + g_total;
            Session["g_total"] = float.Parse(Label1.Text);
            Application["v_data"] = table;
            string[] prod_data = {Convert.ToString(Session["g_total"]), Convert.ToString(Session["s_date"]), Convert.ToString(Session["e_date"]) };
            System.IO.File.WriteAllLines(@"c:\Users\shawn\Documents\Visual Studio 2010\Projects\EC - Assignment\info.txt", prod_data);
        }

        public class Product
        {
            public int id;
            public String name;
            public String description;
            public String category;
            public float unit_price_per_day;

            public Product() {
                id = 0;
                name = "";
                description = "";
                category = "";
                unit_price_per_day = 0.00f;
            }            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if ((int) Session["amount"] <= 0)
            {
                Response.Write("<script language=JavaScript>window.alert('please select proper dates and...!')</script>");
            }
            else
            {
                Response.Redirect("Check_out.htm");
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            int p_id = int.Parse(RadioButtonList1.SelectedValue);
            string constr = ConfigurationManager.ConnectionStrings["ec_projConnectionString"].ConnectionString;
            SqlConnection conn = new SqlConnection(constr);
            conn.Open();
            SqlCommand comm = new SqlCommand(constr, conn);
            comm.Connection = conn;
            comm.CommandText = "select * from v_product where prod_id=" + p_id;
            SqlDataReader dr = comm.ExecuteReader();
            dr.Read();
            byte[] img = (byte[])dr["prod_image"] as byte[];
            string img_s = Convert.ToBase64String(img, 0, img.Length);
            Image1.ImageUrl = "data:image/png;base64," + img_s;
        }
    }
}