﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace EC_two____Project
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        public class exchangerate {
            public float us { get; set; }
            public float cn { get; set; }
            public float pound { get; set; }
            public float euro { get; set; }
        }

        [WebMethod]
        public string exch_rates() {
            string json = null;
            string info = new WebClient().DownloadString("https://api.exchangerate-api.com/v4/latest/JMD");
            dynamic j_data = new JavaScriptSerializer().Deserialize<object>(info);
            exchangerate currency = new exchangerate();
            currency.us =(float) Math.Round((1 / j_data["rates"]["USD"]),2);
            currency.cn =(float) Math.Round((1 / j_data["rates"]["CAD"]),2);
            currency.pound =(float) Math.Round((1 / j_data["rates"]["GBP"]),2);
            currency.euro =(float) Math.Round((1 / j_data["rates"]["EUR"]),2);
            var j_obj = new JavaScriptSerializer().Serialize(currency);
            //
            json = "currency: " + j_obj;
            return json;
        }
    }
}
