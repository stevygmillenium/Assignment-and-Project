﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EC_two____Project.Models;

namespace EC_two____Project.Controllers
{
    public class bank_accController : Controller
    {
        //
        // GET: /bank_acc/

        public ActionResult Index()
        {
            var b = new bill_sys_context();
            List<bank_acc> lst = b.b_acc.SqlQuery("select * from bank_acc").ToList<bank_acc>();
            return View(lst);
        }

        //
        // GET: /bank_acc/Details/5

        public ActionResult Details(int id)
        {
            var b = new bill_sys_context();
            bank_acc ba = b.b_acc.Find(id);
            return View(ba);
        }

        //
        // GET: /bank_acc/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /bank_acc/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                string u_id = collection["User_id"];
                string name = collection["Name"];
                string addr = collection["Address"];
                float bal =(float) Convert.ToDouble(collection["Balance"]);
                string acc_num = collection["Account_Number"];
                string card_num = collection["Card_Number"];
                string acc_type =collection["Account_type"];
                var b = new bill_sys_context();
                bank_acc ba = new bank_acc() { User_id = u_id, Name = name, Address = addr, Balance = bal, Account_Number = acc_num, Card_Number = card_num, Account_type = acc_type };
                b.b_acc.Add(ba);
                b.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        
        //
        // GET: /bank_acc/Edit/5
 
        public ActionResult Edit(int id)
        {
            var b = new bill_sys_context();
            bank_acc ba = b.b_acc.Find(id);
            return View(ba);
        }

        //
        // POST: /bank_acc/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /bank_acc/Delete/5
 
        public ActionResult Delete(int id)
        {
            var b = new bill_sys_context();
            bank_acc ba = b.b_acc.Find(id);
            return View(ba);
        }

        //
        // POST: /bank_acc/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                var b = new bill_sys_context();
                bank_acc ba = b.b_acc.Find(id);
                b.b_acc.Remove(ba);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
