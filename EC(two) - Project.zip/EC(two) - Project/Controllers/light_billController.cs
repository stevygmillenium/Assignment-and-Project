﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EC_two____Project.Models;

namespace EC_two____Project.Controllers
{
    public class light_billController : Controller
    {
        //
        // GET: /light_bill/

        public ActionResult Index()
        {
            var b = new bill_sys_context();
            List<light_bill> lst = b.l_bill.SqlQuery("select * from light_bill").ToList<light_bill>();
            return View(lst);
        }

        //
        // GET: /light_bill/Details/5

        public ActionResult Details(int id)
        {
            var b = new bill_sys_context();
            light_bill lb = b.l_bill.Find(id);
            return View(lb);
        }

        //
        // GET: /light_bill/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /light_bill/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                DateTime b_gen = Convert.ToDateTime(collection["bill_generation_date"]);
                DateTime b_due = Convert.ToDateTime(collection["bill_due_date"]);
                int prem_num = Convert.ToInt16(collection["premises_number"]);
                string c_id = collection["customer_id"];
                string addr = collection["address"];
                float amt_due = (float)Convert.ToDouble(collection["amount_due"]);
                bill_sys_context b = new bill_sys_context();
                light_bill lb = new light_bill() { bill_generation_date = b_gen, bill_due_date = b_due, premises_number = prem_num, customer_id = c_id, address = addr, amount_due = amt_due };
                b.l_bill.Add(lb);
                b.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        
        //
        // GET: /light_bill/Edit/5
 
        public ActionResult Edit(int id)
        {
            var b = new bill_sys_context();
            light_bill lb = b.l_bill.Find(id);
            return View(lb);
        }

        //
        // POST: /light_bill/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /light_bill/Delete/5
 
        public ActionResult Delete(int id)
        {
            var b = new bill_sys_context();
            light_bill lb = b.l_bill.Find(id);
            return View(lb);
        }

        //
        // POST: /light_bill/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                var b = new bill_sys_context();
                light_bill lb = b.l_bill.Find(id);
                b.l_bill.Remove(lb);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
