﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Web;
using System.Web.Mvc;

namespace EC_two____Project.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Welcome to ASP.NET MVC!";

            return View();
        }
                
        public ActionResult get_data() {
            BasicHttpBinding bind = new BasicHttpBinding();
            EndpointAddress epa = new EndpointAddress("http://localhost:21273/Service1.svc");
            ChannelFactory<IService1> cf = new ChannelFactory<IService1>(bind, epa);
            IService1 ser = cf.CreateChannel();
            string wrd = ser.write();            
            WebService1 ws = new WebService1();
            string hel = ws.exch_rates();            
            return this.Json(new { wrd, hel });
        }

        public ActionResult pay_bill()
        {            
            return View();
        }

        public ActionResult check_account()
        {
            return View();
        }

        public ActionResult administration() { return View(); }

        public ActionResult teller() { return View(); }

        public ActionResult About()
        {
            return View();
        }
    }
}
