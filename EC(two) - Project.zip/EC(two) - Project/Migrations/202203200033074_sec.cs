namespace EC_two____Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class sec : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.bill_payment", "payment_type", c => c.String());
            AddColumn("dbo.bank_acc", "Account_type", c => c.String(nullable: false, maxLength: 7));
            AlterColumn("dbo.bank_acc", "Balance", c => c.Single(nullable: false));
            AlterColumn("dbo.bank_acc", "Account_Number", c => c.String(nullable: false, maxLength: 10));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.bank_acc", "Account_Number", c => c.String(nullable: false, maxLength: 7));
            AlterColumn("dbo.bank_acc", "Balance", c => c.Decimal(nullable: false, precision: 18, scale: 2));
            DropColumn("dbo.bank_acc", "Account_type");
            DropColumn("dbo.bill_payment", "payment_type");
        }
    }
}
