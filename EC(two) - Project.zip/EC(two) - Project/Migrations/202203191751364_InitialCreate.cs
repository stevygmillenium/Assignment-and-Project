namespace EC_two____Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.light_bill",
                c => new
                    {
                        bill_id = c.Int(nullable: false, identity: true),
                        bill_generation_date = c.DateTime(nullable: false),
                        bill_due_date = c.DateTime(nullable: false),
                        premises_number = c.Int(nullable: false),
                        customer_id = c.String(nullable: false),
                        address = c.String(),
                        amount_due = c.Single(nullable: false),
                    })
                .PrimaryKey(t => t.bill_id);
            
            CreateTable(
                "dbo.bill_payment",
                c => new
                    {
                        payment_num = c.Int(nullable: false, identity: true),
                        bill_id = c.Int(nullable: false),
                        payment_date = c.DateTime(nullable: false),
                        payment_amount = c.Single(nullable: false),
                    })
                .PrimaryKey(t => t.payment_num);
            
            CreateTable(
                "dbo.bank_acc",
                c => new
                    {
                        User_id = c.String(nullable: false, maxLength: 128),
                        Name = c.String(nullable: false),
                        Address = c.String(),
                        Balance = c.Decimal(nullable: false, precision: 18, scale: 2),
                        Account_Number = c.String(nullable: false, maxLength: 7),
                        Card_Number = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.User_id);
            
            CreateTable(
                "dbo.bank_trans",
                c => new
                    {
                        trans_id = c.Int(nullable: false, identity: true),
                        Card_Number = c.String(),
                        amount = c.Single(nullable: false),
                        trans_date = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.trans_id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.bank_trans");
            DropTable("dbo.bank_acc");
            DropTable("dbo.bill_payment");
            DropTable("dbo.light_bill");
        }
    }
}
