﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Objects;
using System.Linq;
using System.Web;

namespace EC_two____Project.Models
{
    public class bill_sys_context:DbContext
    {
        public DbSet<light_bill> l_bill { get; set; }
        public DbSet<bill_payment> bill_p { get; set; }
        public DbSet<bank_acc> b_acc { get; set; }
        public DbSet<bank_trans> b_t { get; set; }        
    }
}