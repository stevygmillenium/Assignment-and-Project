﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EC_two____Project.Models
{
    public class bank_trans
    {
        [Key]
        public int trans_id { get; set; }
        public string Card_Number { get; set; }
        public float amount { get; set; }
        public DateTime trans_date { get; set; }
    }
}