﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EC_two____Project.Models
{
    public class light_bill
    {
        [Key]
        public int bill_id { get; set; }
        [Required(ErrorMessage = "enter bill generation date")]
        [Display(Name = "bill generation date")]
        public DateTime bill_generation_date { get; set; }
        [Required(ErrorMessage = "enter bill due date")]
        [Display(Name = "bill due date")]
        public DateTime bill_due_date { get; set; }
        [Required(ErrorMessage = "enter premises number")]
        [Display(Name = "premises number")]
        public int premises_number { get; set; }
        [Required(ErrorMessage = "enter")]
        [Display(Name = "customer id")]
        public string customer_id { get; set; }
        public string address { get; set; }
        [Required(ErrorMessage = "enter amount due")]
        [Display(Name = "amount due")]
        public float amount_due { get; set; }
    }
}