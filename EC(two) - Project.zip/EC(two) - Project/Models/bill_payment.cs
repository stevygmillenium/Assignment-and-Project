﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EC_two____Project.Models
{
    public class bill_payment
    {
        [Key]
        public int payment_num { get; set; }
        public int bill_id { get; set; }
        public DateTime payment_date { get; set; }
        public string payment_type { get; set; }
        public float payment_amount { get; set; }
    }
}