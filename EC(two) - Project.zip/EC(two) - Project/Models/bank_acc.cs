﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EC_two____Project.Models
{
    public class bank_acc
    {
        [Key]
        public string User_id { get; set; }
        [Required(ErrorMessage = "enter name")]
        public string Name { get; set; }
        public string Address { get; set; }
        [Required(ErrorMessage = "enter balance")]//[Range(10000,float.MaxValue)]              
        public float Balance { get; set; }
        [Required(ErrorMessage = "enter account number")]
        [Display(Name = "Account Number")]
        [MaxLength(10)]
        public string Account_Number { get; set; }
        [Required(ErrorMessage = "enter card number")]
        [Display(Name = "Card Number")]
        public string Card_Number { get; set; }
        [Required(ErrorMessage = "enter account type")]
        [Display(Name = "Account type")]
        [MaxLength(7)]
        public string Account_type { get; set; }
    }
}