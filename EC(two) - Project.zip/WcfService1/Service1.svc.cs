﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    public class Service1 : IService1
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public bool pay_bill(int bill_id, float amt, string card_num)
        {
            string constr = "Data Source=LAPTOP-RD6SKICU\\SQLEXPRESS;Initial Catalog=EC_two____Project.Models.bill_sys_context;Integrated Security=True";
            System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(constr);
            conn.Open();
            System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand(constr, conn);
            comm.Connection = conn;
            comm.CommandText = "select * from bank_acc where Card_Number=@c_num";
            comm.Parameters.Add("@c_num", card_num);
            SqlDataReader dr = null;
            dr = comm.ExecuteReader();
            dr.Read();
            //var bs_c = new bill_sys_context();
            bank_acc ba = new bank_acc();
            ba.Balance =(float) dr["Balance"];
            dr.Close();
            bank_trans bt = new bank_trans();
            comm.CommandText = "select * from light_bill where bill_id=@id";
            comm.Parameters.Add("@id", bill_id);
            dr = comm.ExecuteReader();
            dr.Read();
            light_bill lb = new light_bill();
            lb.amount_due =(float) dr["amount_due"];
            dr.Close();
            bill_payment bp = new bill_payment();
            bool stat = false;
            if (ba.Balance < lb.amount_due || ba.Balance < amt || amt < 0) { }
            else
            {
                float bal = 0;
                if (amt > 0)
                {
                    bal = ba.Balance - amt;
                    bt.amount = amt * -1;
                    bp.payment_amount = amt;
                }
                else
                {
                    bal = ba.Balance - lb.amount_due;
                    bt.amount = lb.amount_due * -1;
                    bp.payment_amount = lb.amount_due;
                }
                //ba.Balance = bal;
                comm.CommandText = "update bank_acc set Balance=@bal where Card_Number=@c_num";
                comm.Parameters.Add("@bal", bal);
                comm.ExecuteNonQuery();
                bt.Card_Number = card_num;
                bt.trans_date = DateTime.Now;
                comm.CommandText = "insert into bank_trans (Card_Number,amount,trans_date) values (@c_num,@bt_amt,@t_date)";
                comm.Parameters.Add("@bt_amt", bt.amount);
                comm.Parameters.Add("@t_date", bt.trans_date);
                comm.ExecuteNonQuery();
                //bs_c.b_t.Add(bt);
                bp.bill_id = bill_id;
                bp.payment_date = DateTime.Now;
                bp.payment_type = "card";
                comm.CommandText = "insert into bill_payment (bill_id,payment_date,payment_type,payment_amount) values (@id,@t_date,@p_t,@bp_amt)";
                comm.Parameters.Add("@p_t", bp.payment_type);
                comm.Parameters.Add("@bp_amt", bp.payment_amount);
                comm.ExecuteNonQuery();
                //bs_c.bill_p.Add(bp);
                //bs_c.SaveChanges();
                stat = true;
            }
            return stat;
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
