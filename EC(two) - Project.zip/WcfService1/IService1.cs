﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        string GetData(int value);

        [OperationContract]
        CompositeType GetDataUsingDataContract(CompositeType composite);

        [OperationContract]
        bool pay_bill(int bill_id, float amt, string card_num);

        // TODO: Add your service operations here
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }
    [DataContract]
    public class bank_acc
    {
        [DataMember]
        public string User_id { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Address { get; set; }
        [DataMember]
        public float Balance { get; set; }
        [DataMember]
        public string Account_Number { get; set; }
        [DataMember]
        public string Card_Number { get; set; }
        [DataMember]
        public string Account_type { get; set; }
    }
    [DataContract]
    public class bank_trans
    {
        [DataMember]
        public int trans_id { get; set; }
        [DataMember]
        public string Card_Number { get; set; }
        [DataMember]
        public float amount { get; set; }
        [DataMember]
        public DateTime trans_date { get; set; }
    }
    [DataContract]
    public class light_bill
    {
        [DataMember]
        public int bill_id { get; set; }
        [DataMember]
        public DateTime bill_generation_date { get; set; }
        [DataMember]
        public DateTime bill_due_date { get; set; }
        [DataMember]
        public int premises_number { get; set; }
        [DataMember]
        public string customer_id { get; set; }
        [DataMember]
        public string address { get; set; }
        [DataMember]
        public float amount_due { get; set; }
    }
    [DataContract]
    public class bill_payment
    {
        [DataMember]
        public int payment_num { get; set; }
        [DataMember]
        public int bill_id { get; set; }
        [DataMember]
        public DateTime payment_date { get; set; }
        [DataMember]
        public string payment_type { get; set; }
        [DataMember]
        public float payment_amount { get; set; }
    }
}
